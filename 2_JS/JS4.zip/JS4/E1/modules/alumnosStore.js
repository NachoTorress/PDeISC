/**
 * modules/alumnosStore.js
 * Almacenamiento en memoria de la lista de alumnos.
 * Actúa como "base de datos" provisional para el ejercicio 4.
 * Entrada: llamadas desde alumnosRouter.js
 * Salida: datos estructurados de alumnos con id y fecha de creación
 */

/** @type {Array<{id:number, nombre:string, email:string, materia:string, createdAt:string}>} */
let alumnos = [
  { id: 1, nombre: "Lucas Ramírez", email: "lucas@mail.com", materia: "Redes", createdAt: "15/06/25" },
  { id: 2, nombre: "Valentina Torres", email: "valen@mail.com", materia: "Programación", createdAt: "16/06/25" },
  { id: 3, nombre: "Mateo Gómez", email: "mateo@mail.com", materia: "Base de Datos", createdAt: "20/06/25" },
];

let nextId = 4;

/**
 * Formatea la fecha actual como DD/MM/AA
 * @returns {string}
 */
function formatDate() {
  const d = new Date();
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yy = String(d.getFullYear()).slice(-2);
  return `${dd}/${mm}/${yy}`;
}

/**
 * Devuelve todos los alumnos.
 * @returns {Array}
 */
export function getAlumnos() {
  return alumnos;
}

/**
 * Agrega un nuevo alumno.
 * @param {{ nombre:string, email:string, materia:string }} data
 * @returns {object} El alumno creado con id y fecha
 */
export function addAlumno(data) {
  const alumno = { id: nextId++, ...data, createdAt: formatDate() };
  alumnos.push(alumno);
  return alumno;
}

/**
 * Actualiza un alumno existente.
 * @param {number} id
 * @param {object} data - Campos a actualizar
 * @returns {object|null} El alumno actualizado o null si no existe
 */
export function updateAlumno(id, data) {
  const idx = alumnos.findIndex((a) => a.id === id);
  if (idx === -1) return null;
  alumnos[idx] = { ...alumnos[idx], ...data };
  return alumnos[idx];
}

/**
 * Elimina un alumno por id.
 * @param {number} id
 * @returns {object|null} El alumno eliminado o null si no existe
 */
export function deleteAlumno(id) {
  const idx = alumnos.findIndex((a) => a.id === id);
  if (idx === -1) return null;
  const [eliminado] = alumnos.splice(idx, 1);
  return eliminado;
}