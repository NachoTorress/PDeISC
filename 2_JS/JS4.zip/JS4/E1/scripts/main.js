/**
 * scripts/main.js
 * Punto de entrada principal de la aplicación.
 * Orquesta: cambio de tabs, toggle de tema, scroll-to-top, y carga de módulos de ejercicios.
 * Entrada: eventos DOM
 * Salida: interacción con módulos de cada ejercicio y cambios en el DOM
 */

import { initEjercicio1 } from "./ejercicio1.js";
import { initEjercicio2 } from "./ejercicio2.js";
import { initEjercicio3 } from "./ejercicio3.js";
import { initEjercicio4 } from "./ejercicio4.js";

// ─────────────────────── TEMA ───────────────────────
/**
 * Aplica el tema (dark/light) al documento y actualiza el ícono del botón.
 * @param {"dark"|"light"} theme
 */
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  const stylesheet = document.getElementById("theme-stylesheet");
  stylesheet.href = `/styles/${theme}.css`;
  const icon = document.getElementById("themeIcon");
  icon.className = theme === "dark" ? "bi bi-moon-fill" : "bi bi-sun-fill";
  localStorage.setItem("theme", theme);
}

/**
 * Inicializa el toggle de tema y aplica el guardado previamente.
 */
function initTheme() {
  const saved = localStorage.getItem("theme") || "dark";
  applyTheme(saved);

  document.getElementById("themeToggle").addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme");
    applyTheme(current === "dark" ? "light" : "dark");
  });
}

// ─────────────────────── TABS ───────────────────────
/**
 * Activa el panel de ejercicio indicado y actualiza los tabs y nav-links.
 * @param {string|number} num - Número del ejercicio (1-4)
 */
function activateExercise(num) {
  // Tabs
  document.querySelectorAll(".ex-tab").forEach((t) => {
    t.classList.toggle("active", t.dataset.exercise === String(num));
    t.setAttribute("aria-selected", t.dataset.exercise === String(num));
  });

  // Paneles
  document.querySelectorAll(".exercise-panel").forEach((p) => {
    p.classList.toggle("active", p.id === `panel-${num}`);
  });

  // Nav links
  document.querySelectorAll(".nav-link[data-exercise]").forEach((l) => {
    l.classList.toggle("active", l.dataset.exercise === String(num));
  });

  localStorage.setItem("activeExercise", num);
}

/**
 * Inicializa los tabs y nav-links de ejercicios.
 */
function initTabs() {
  const savedEx = localStorage.getItem("activeExercise") || "1";
  activateExercise(savedEx);

  document.querySelectorAll(".ex-tab").forEach((tab) => {
    tab.addEventListener("click", () => activateExercise(tab.dataset.exercise));
  });

  document.querySelectorAll(".nav-link[data-exercise]").forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      activateExercise(link.dataset.exercise);
      // Cerrar navbar en mobile
      const collapse = document.getElementById("navbarContent");
      if (collapse.classList.contains("show")) {
        const bsCollapse = bootstrap.Collapse.getOrCreateInstance(collapse);
        bsCollapse.hide();
      }
    });
  });
}

// ─────────────────────── SCROLL TO TOP ───────────────────────
/**
 * Inicializa el botón de scroll al inicio de la página.
 * El botón se muestra cuando el usuario baja más de 300px.
 */
function initScrollTop() {
  const btn = document.getElementById("scrollTopBtn");
  window.addEventListener("scroll", () => {
    btn.classList.toggle("visible", window.scrollY > 300);
  });
  btn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

// ─────────────────────── INIT ───────────────────────
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initTabs();
  initScrollTop();
  initEjercicio1();
  initEjercicio2();
  initEjercicio3();
  initEjercicio4();
});