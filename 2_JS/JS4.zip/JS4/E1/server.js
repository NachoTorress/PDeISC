/**
 * server.js
 * Servidor Express que:
 *  1. Sirve archivos estáticos (HTML, CSS, JS) desde las carpetas del proyecto
 *  2. Expone la API REST /api/alumnos para el Ejercicio 4
 * Puerto: 3000
 */

import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import alumnosRouter from "./modules/alumnosRouter.js";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ─────────────────────── MIDDLEWARE ───────────────────────
// Parsear JSON en el body de las peticiones POST/PUT
app.use(express.json());

// ─────────────────────── ARCHIVOS ESTÁTICOS ───────────────────────
// Sirve /styles/*, /scripts/* y cualquier otro archivo de la carpeta raíz del proyecto
app.use(express.static(__dirname));

// ─────────────────────── API ───────────────────────
// Monta el router de alumnos en /api/alumnos (Ejercicio 4)
app.use("/api/alumnos", alumnosRouter);

// ─────────────────────── RUTA PRINCIPAL ───────────────────────
// Sirve el HTML principal en la raíz
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "pages", "index.html"));
});

// ─────────────────────── INICIO ───────────────────────
app.listen(3000, () => {
  console.log("Servidor corriendo en http://localhost:3000");
});
