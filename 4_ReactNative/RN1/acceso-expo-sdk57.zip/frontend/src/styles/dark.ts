export const dark = {
  background: '#101C19', surface: '#1A2925', text: '#F4F4EE', muted: '#B5C7BD',
  border: '#4B6659', accent: '#A7DCC0', accentText: '#11251B', soft: '#29483A',
  error: '#FFB3A9', errorSoft: '#512B2C', input: '#21332C', line: '#365044'
};
