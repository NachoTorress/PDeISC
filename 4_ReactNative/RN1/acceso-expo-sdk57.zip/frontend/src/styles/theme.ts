import { StyleSheet } from 'react-native';
import { dark } from './dark';
import { light } from './light';

export type Palette = typeof light;
export const palette = (mode: 'light' | 'dark'): Palette => mode === 'dark' ? dark : light;

export const stylesFor = (c: Palette) => StyleSheet.create({
  screen: { flex: 1, backgroundColor: c.background },
  scroll: { flexGrow: 1, paddingHorizontal: 22, paddingVertical: 28, alignItems: 'center', justifyContent: 'center' },
  content: { width: '100%', maxWidth: 1600 },
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 34 },
  brand: { color: c.accent, fontSize: 23, fontWeight: '800', letterSpacing: -0.4 },
  themeButton: { paddingVertical: 9, paddingHorizontal: 14, borderWidth: 1, borderColor: c.border, borderRadius: 22 },
  themeText: { color: c.text, fontWeight: '700' },
  heading: { color: c.text, fontSize: 38, lineHeight: 43, fontWeight: '800', letterSpacing: -1.1, marginBottom: 10 },
  intro: { color: c.muted, fontSize: 16, lineHeight: 24, marginBottom: 28 },
  panel: { backgroundColor: c.surface, borderRadius: 16, padding: 22 },
  label: { color: c.text, fontWeight: '700', marginBottom: 7, fontSize: 14 },
  input: { backgroundColor: c.input, borderWidth: 1, borderColor: c.border, borderRadius: 11, paddingHorizontal: 15, paddingVertical: 12, color: c.text, fontSize: 16, minHeight: 50 },
  inputError: { borderColor: c.error, borderWidth: 2 },
  field: { marginBottom: 17 },
  error: { color: c.error, fontSize: 13, lineHeight: 18, marginTop: 5 },
  banner: { color: c.error, backgroundColor: c.errorSoft, padding: 12, borderRadius: 10, marginBottom: 16, lineHeight: 20 },
  success: { color: c.text, backgroundColor: c.soft, padding: 12, borderRadius: 10, marginBottom: 16, lineHeight: 20 },
  button: { backgroundColor: c.accent, borderRadius: 11, minHeight: 51, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, marginTop: 5 },
  buttonText: { color: c.accentText, fontSize: 16, fontWeight: '800' },
  buttonDisabled: { opacity: 0.55 },
  secondaryButton: { borderColor: c.border, borderWidth: 1, backgroundColor: c.surface },
  secondaryText: { color: c.text, fontWeight: '700', fontSize: 15 },
  textButton: { paddingVertical: 10, alignSelf: 'flex-start' },
  textButtonText: { color: c.accent, fontWeight: '700', fontSize: 15 },
  divider: { height: 1, backgroundColor: c.line, marginVertical: 22 },
  providerRow: { flexDirection: 'row', gap: 9, flexWrap: 'wrap' },
  providerButton: { flexGrow: 1, minWidth: 90, borderWidth: 1, borderColor: c.border, borderRadius: 10, padding: 13, alignItems: 'center' },
  providerText: { color: c.text, fontWeight: '700' },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginBottom: 10 },
  chip: { borderWidth: 1, borderColor: c.border, borderRadius: 9, padding: 9, backgroundColor: c.input },
  chipSelected: { backgroundColor: c.soft, borderColor: c.accent },
  chipText: { color: c.text, fontSize: 13, lineHeight: 18 },
  smallTitle: { color: c.text, fontSize: 17, fontWeight: '800', marginBottom: 13 },
  detail: { color: c.muted, fontSize: 14, lineHeight: 21 },
  detailStrong: { color: c.text, fontWeight: '700' },
  footer: { color: c.muted, textAlign: 'center', fontSize: 12, marginTop: 22 }
});
